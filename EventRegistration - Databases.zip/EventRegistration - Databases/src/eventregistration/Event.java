/**
 * Event.java
 * This class creates and stores the attendee details in a database
 * @author Kruben Naidoo
 * Date: Sunday, 13 September 2020
 */

package eventregistration;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Event {
    static final String DATABASE_URL = "jdbc:derby://localhost:1527/Sunshine";
    private final String username = "Administrator";
    private final String password = "Password";
    
    private String studentNumber;
    private String firstName;
    private String lastName;
    private String programme;
    private String hasData;
    private String hasDevice;
    
    // Constructors
    public Event(String studentNumber) {
        this.studentNumber = studentNumber;
    }
    
    public Event(String studentNumber, String firstName, String lastName, String programme, String hasData, String hasDevice) {
        this.studentNumber = studentNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        this.programme = programme;
        this.hasData = hasData;
        this.hasDevice = hasDevice;
    }

    // Getters
    public String getStudentNumber() {
        return studentNumber;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getProgramme() {
        return programme;
    }

    public String getHasData() {
        return hasData;
    }

    public String getHasDevice() {
        return hasDevice;
    }
    
    public static ArrayList<String> getStudentNumbers() {
        Connection connection = null;   
        Statement statement = null;     
        ResultSet resultSet = null;     
        ArrayList<String> list = new ArrayList<String>();
        
        try {
            connection = DriverManager.getConnection(DATABASE_URL, "Administrator", "Password");
            statement = connection.createStatement();
            resultSet = statement.executeQuery("SELECT StudentNumber FROM Event");
            while (resultSet.next()) {
                list.add(resultSet.getString("StudentNumber"));
            }    
        }
        catch(SQLException sqlException) {
            JOptionPane.showMessageDialog(null, "Error: " + sqlException);
        }
        finally {
            // Method 1
            try {
                if (resultSet != null)
                    resultSet.close();
            }
            catch(Exception exception){
                JOptionPane.showMessageDialog(null, exception.getMessage(), "Warning", JOptionPane.ERROR_MESSAGE);
            }
            try {
                if (statement != null)
                    statement.close();
            }
            catch(Exception exception){
                JOptionPane.showMessageDialog(null, exception.getMessage(), "Warning", JOptionPane.ERROR_MESSAGE);
            }
            try {
                if (connection != null)
                    connection.close();
            }
            catch(Exception exception){
                JOptionPane.showMessageDialog(null, exception.getMessage(), "Warning", JOptionPane.ERROR_MESSAGE);
            }
        }
            
        return list;
    }
    
    public void populateStudent() {
        Connection connection = null;   
        Statement statement = null;     
        ResultSet resultSet = null;     
                
        try {
            connection = DriverManager.getConnection(DATABASE_URL, "Administrator", "Password");
            statement = connection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM Event WHERE StudentNumber = '" + studentNumber + "'");
            if (resultSet.next()) {
                firstName = resultSet.getString("FirstName");
                lastName = resultSet.getString("LastName");
                programme = resultSet.getString("Programme");
                hasData = resultSet.getString("HasData");
                hasDevice = resultSet.getString("HasDevice");
            }    
            else
                ;//error in studentNumber?
        }
        catch(SQLException sqlException) {
            JOptionPane.showMessageDialog(null, "Error: " + sqlException);
        }
        finally {
            // Method 1
            try {
                if (resultSet != null)
                    resultSet.close();
            }
            catch(Exception exception){
                JOptionPane.showMessageDialog(null, exception.getMessage(), "Warning", JOptionPane.ERROR_MESSAGE);
            }
            try {
                if (statement != null)
                    statement.close();
            }
            catch(Exception exception){
                JOptionPane.showMessageDialog(null, exception.getMessage(), "Warning", JOptionPane.ERROR_MESSAGE);
            }
            try {
                if (connection != null)
                    connection.close();
            }
            catch(Exception exception){
                JOptionPane.showMessageDialog(null, exception.getMessage(), "Warning", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    public void update() {
        Connection connection = null;   // manage connections
        Statement statement = null;     // query statement
        int ok; 

        try {
            connection = DriverManager.getConnection(DATABASE_URL, "Administrator", "Password");
            statement = connection.createStatement();    
            ok = statement.executeUpdate("UPDATE Event SET FirstName='" + firstName + "', " 
                                                + "LastName='" + lastName + "', " 
                                                + "Programme='" + programme + "', " 
                                                + "HasData='" + hasData + "', "
                                                + "HasDevice='" + hasDevice + "' "
                                                + "WHERE StudentNumber='" + studentNumber + "'");
            if (ok > 0) {
                JOptionPane.showMessageDialog(null, "Success! The information has been updated.");
            }
            else {
                JOptionPane.showMessageDialog(null, "Error: Could not update information.");
            }
        }
        catch(SQLException sqlException) {
            JOptionPane.showMessageDialog(null, "Error: Could not update. " + sqlException);
        }
        finally {
            // Method 1
            try {
                if (statement != null)
                    statement.close();
            }
            catch(Exception exception){
                JOptionPane.showMessageDialog(null, exception.getMessage(), "Warning", JOptionPane.ERROR_MESSAGE);
            }
            try {
                if (connection != null)
                    connection.close();
            }
            catch(Exception exception){
                JOptionPane.showMessageDialog(null, exception.getMessage(), "Warning", JOptionPane.ERROR_MESSAGE);
            }
        }
    }  
}
			